(function(){
  const data = (window.__DATA__ || []).slice();
  const grid = document.getElementById('grid');
  const search = document.getElementById('search');
  const year = document.getElementById('year');
  if(year) year.textContent = new Date().getFullYear();

  function render(items){
    grid.innerHTML = '';
    for(const item of items){
      const card = document.createElement('article');
      card.className = 'card';

      const a = document.createElement('a');
      a.href = item.pdf;
      a.target = '_blank';
      a.rel = 'noopener noreferrer';
      a.setAttribute('aria-label', 'Abrir PDF: ' + item.title);

      const media = document.createElement('div');
      media.className = 'media';
      const img = document.createElement('img');
      img.src = item.thumb;
      img.alt = item.title;
      img.className = 'thumb';
      img.loading = 'lazy';
      img.decoding = 'async';
      media.appendChild(img);

      const cap = document.createElement('div');
      cap.className = 'caption';
      const span = document.createElement('span');
      span.className = 'title';
      span.textContent = item.title;
      cap.appendChild(span);

      a.appendChild(media);
      a.appendChild(cap);
      card.appendChild(a);
      grid.appendChild(card);
    }
  }

  render(data);

  // Non-destructive search: filter; when cleared, original order returns
  search && search.addEventListener('input', function(){
    const q = this.value.trim().toLowerCase();
    if(!q){ render(data); }
    else { render(data.filter(it => it.title.toLowerCase().includes(q))); }
  });
})();